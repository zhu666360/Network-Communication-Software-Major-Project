package com.example.admin.entity;

public record UserSummary(String username, String displayName, boolean online) {}
