package com.example.admin.entity;

public record StatsSummary(int totalUsers, int onlineUsers, int activeCalls, long messagesToday) {}
