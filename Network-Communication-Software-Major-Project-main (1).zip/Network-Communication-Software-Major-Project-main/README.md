# SIP 通信系统

> 基于 JAIN SIP + Spring Boot + JavaFX 的即时通信系统  
> 版本：1.0.0-SNAPSHOT

## 项目简介

完整的 SIP 通信系统，支持即时消息和语音通话。

**系统架构：**
- **SIP 服务器（MSS）** - SIP 协议处理和路由
- **业务服务器（admin-server）** - REST API 服务
- **桌面客户端（sip-client）** - JavaFX 图形界面 + 命令行

## 系统架构

```
┌─────────────────┐         ┌─────────────────┐
│   Java PC 客户端   │ ←─SIP─→ │   MSS SIP 服务器  │
│  (sip-client)   │         │                 │
└────────┬────────┘         └─────────────────┘
         │
         │ HTTP REST API
         │
         ↓
┌─────────────────┐
│  Java 业务服务器   │
│  (admin-server) │
│  - 用户管理       │
│  - 消息存储       │
│  - 通话记录       │
│  - 统计报表       │
└─────────────────┘
```

## 技术栈

| 模块 | 技术 | 版本 |
|------|------|------|
| 构建工具 | Maven | 3.x |
| JDK | OpenJDK | 17 |
| SIP 协议 | JAIN SIP RI | 1.3.0-91 |
| 服务端 | Spring Boot | 3.2.5 |
| 客户端 UI | JavaFX | 21.0.1 |
| 本地存储 | SQLite | 3.45.0.0 |
| 认证 | JWT | 0.12.3 |

## 项目结构

```
Project/
├── pom.xml                                    # 父 POM，管理依赖版本
│
├── sip-client/                                # Java PC 客户端模块
│   ├── pom.xml
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/example/sipclient/
│   │   │   │   ├── SipClientApplication.java          # 主应用入口类
│   │   │   │   ├── sip/                               # SIP 协议层
│   │   │   │   │   └── SipUserAgent.java              # SIP 用户代理(注册/消息/呼叫)
│   │   │   │   ├── call/                              # 呼叫管理
│   │   │   │   │   ├── CallManager.java               # 呼叫管理器
│   │   │   │   │   └── CallSession.java               # 呼叫会话
│   │   │   │   ├── chat/                              # 消息处理
│   │   │   │   │   ├── MessageHandler.java            # 消息处理器
│   │   │   │   │   └── ChatSession.java               # 聊天会话
│   │   │   │   ├── media/                             # 媒体会话(RTP音频待实现)
│   │   │   │   │   └── AudioSession.java              # 音频会话
│   │   │   │   ├── config/                            # 配置管理
│   │   │   │   │   └── SipConfig.java                 # SIP 配置
│   │   │   │   ├── ui/                                # 命令行界面
│   │   │   │   │   ├── ConsoleMain.java               # 命令行主程序
│   │   │   │   │   ├── QuickStartUser101.java         # 快速启动脚本(用户101)
│   │   │   │   │   └── QuickStartUser102.java         # 快速启动脚本(用户102)
│   │   │   │   └── gui/                               # JavaFX 图形界面 ✅
│   │   │   │       ├── SipClientApp.java              # JavaFX 主应用
│   │   │   │       ├── controller/                    # FXML 控制器
│   │   │   │       │   ├── LoginController.java       # 登录+资源清理
│   │   │   │       │   ├── MainController.java        # 主界面+联系人+消息
│   │   │   │       │   ├── IncomingCallController.java# 来电弹窗
│   │   │   │       │   ├── CallController.java        # 通话窗口
│   │   │   │       │   └── SettingsController.java    # 设置界面 ✅
│   │   │   │       ├── model/                         # 数据模型
│   │   │   │       │   ├── Contact.java               # 联系人实体
│   │   │   │       │   └── Message.java               # 消息实体
│   │   │   │       └── storage/                       # 本地存储 ✅
│   │   │   │           └── LocalDatabase.java         # SQLite数据库(联系人/消息)
│   │   │   └── resources/
│   │   │       ├── fxml/                              # JavaFX 界面文件
│   │   │       │   ├── login.fxml                     # 登录界面
│   │   │       │   ├── main.fxml                      # 主界面
│   │   │       │   ├── incoming_call.fxml             # 来电弹窗
│   │   │       │   ├── call.fxml                      # 通话窗口
│   │   │       │   └── settings.fxml                  # 设置界面 ✅
│   │   │       └── css/
│   │   │           └── style.css                      # 样式文件
│   │   └── test/java/com/example/sipclient/
│   │       ├── call/                                  # 呼叫相关测试
│   │       └── chat/                                  # 聊天相关测试
│   └── target/                                        # 编译输出目录
│       ├── classes/                                   # 编译后的class文件
│       ├── generated-sources/annotations/
│       ├── maven-status/maven-compiler-plugin/
│       └── test-classes/                              # 测试类编译输出
│
├── admin-server/                                      # Java 业务服务器模块
│   ├── pom.xml
│   ├── src/
│   │   └── main/
│   │       ├── java/com/example/admin/
│   │       │   ├── AdminServerApplication.java       # 服务器主应用
│   │       │   ├── controller/                       # REST API 控制器
│   │       │   │   ├── AuthController.java           # 认证接口
│   │       │   │   ├── UserController.java           # 用户管理
│   │       │   │   ├── MessageController.java        # 消息管理
│   │       │   │   ├── CallController.java           # 呼叫管理
│   │       │   │   └── StatsController.java          # 统计报表
│   │       │   ├── service/                          # 业务逻辑层
│   │       │   │   ├── SipService.java               # SIP 服务封装
│   │       │   │   └── UserService.java              # 用户服务
│   │       │   ├── entity/                           # 数据模型
│   │       │   ├── repository/                       # 数据访问层
│   │       │   ├── config/                           # 配置类
│   │       │   │   ├── WebConfig.java                # Web 配置
│   │       │   │   └── WebSocketConfig.java          # WebSocket 配置
│   │       │   ├── util/                             # 工具类
│   │       │   │   └── JwtUtil.java                  # JWT 工具
│   │       │   └── dto/                              # 数据传输对象
│   │       └── resources/
│   │           ├── application.yml                   # 应用配置
│   │           └── static/                           # 静态资源
│   │               ├── index.html                    # 前端页面
│   │               ├── app.js                        # 前端脚本
│   │               └── styles.css                    # 前端样式
│   └── target/                                       # 编译输出目录
│       ├── classes/                                  # 编译后的class文件
│       ├── generated-sources/annotations/
│       ├── maven-status/maven-compiler-plugin/
│       └── test-classes/
│
├── docs/                                             # 文档目录
│   └── archive/                                      # 归档文档
│       ├── GUI_FEATURES_COMPLETION.md                # GUI功能完成报告
│       └── TASK-DISTRIBUTION.md                      # 任务分配文档
│
├── README.md                                         # 项目说明文档(本文件)
├── QUICKSTART.md                                     # 快速开始指南
├── start-gui.ps1                                     # GUI 客户端启动脚本 ✅
├── start-sip-user101.ps1                             # 命令行客户端启动脚本(用户101)
├── start-sip-user102.ps1                             # 命令行客户端启动脚本(用户102)
└── run-sip-client.ps1                                # 通用命令行启动脚本
```

## 核心功能

### ✅ 已完成
- SIP 协议实现（注册/消息/呼叫）
- JavaFX 图形界面客户端
  - 即时消息收发（类微信气泡）
  - 联系人管理（增删改查）
  - 语音呼叫（信令层）
  - 本地存储（SQLite）
  - 设置界面
- 命令行客户端
- Spring Boot REST API 服务器

### 🔄 开发中
- RTP 音频传输
- 服务器数据持久化
- 群聊功能

### 📋 待开发
- 视频通话
- 文件传输
- NAT 穿透

---

## 快速开始

### 环境要求
- JDK 17
- Maven 3.x
- MSS SIP 服务器（可选）

### 启动客户端

**图形界面（推荐）：**
```powershell
.\start-gui.ps1
```

**命令行客户端：**
```powershell
.\start-sip-user101.ps1  # 用户 101
.\start-sip-user102.ps1  # 用户 102
```

### 启动服务器
```powershell
cd admin-server
mvn spring-boot:run
```

服务器运行在 `http://localhost:8081`

---

## JavaFX 图形界面详解 ✨

### 界面组件

#### 1. 登录界面
- 简洁的表单设计
- 预填充默认配置
- 异步连接和注册
- 进度指示器和状态提示

#### 2. 主界面

**布局结构：**
```
┌─────────────────────────────────────────────────────┐
│  SIP 客户端 - sip:101@10.29.133.174:5060   [最小化][关闭] │
├──────────┬──────────────────────────────────────────┤
│ 联系人列表 │  [联系人名称]              [📞 语音通话]  │
│          │  ────────────────────────────────────── │
│ 👤 102    │                                          │
│ 最后消息  │     💬 聊天消息区域                      │
│ [1] 12:30│     （类微信气泡，蓝色=发送，灰色=接收）   │
│          │                                          │
│ 👤 111    │                                          │
│ 最后消息  │                                          │
│ 13:45    │  ────────────────────────────────────── │
│          │  ┌────────────────────────────────────┐ │
│ 👤 103    │  │ 输入消息...                        │ │
│          │  │ (Shift+Enter 换行, Enter 发送)     │ │
│          │  └────────────────────────────────────┘ │
│          │                            [发送]        │
├──────────┴──────────────────────────────────────────┤
│  状态栏：已连接                                      │
└─────────────────────────────────────────────────────┘
```

**功能特性:**
- **联系人列表**
  - 显示联系人头像(占位符)
  - 最后一条消息预览
  - 消息时间戳
  - 未读消息红色徽章
  - ➕ 快速添加联系人 ✅
  - 🔍 实时搜索(昵称/ID/消息) ✅
  - 右键菜单(编辑/删除) ✅
  
- **聊天窗口**
  - 消息气泡样式(发送=蓝色,接收=灰色)
  - 自动滚动到最新消息
  - 消息时间显示
  - Enter 发送,Shift+Enter 换行
  - 😀 表情符号选择器 ✅
  - 🔍 消息历史搜索 ✅
  - 📎 文件附件(占位)
  
- **语音通话**
  - 点击按钮发起呼叫
  - 自动打开通话窗口
  
- **设置功能** ✅
  - 通知开关(桌面通知/提示音)
  - 音量调节
  - 音频设备选择
  - 开机自启动
  - 聊天记录保存
  
- **数据持久化** ✅
  - SQLite 本地数据库
  - 联系人自动保存
  - 聊天记录本地缓存
  - 启动时自动加载历史

- **注销与资源释放** ✅
  - 关闭窗口自动注销(向MSS发送UNREGISTER)
  - 三层端口释放保护机制
  - 程序退出后端口立即可重用

#### 3. 来电弹窗
- 模态对话框
- 显示来电方信息
- 接听（绿色）/ 拒接（红色）按钮
- 阻塞式交互

#### 4. 通话窗口
- 独立窗口
- 紫色渐变背景
- 实时通话计时（HH:MM:SS）
- 挂断按钮（红色）
- 静音按钮（待实现）

#### 5. 设置界面 ✅
- 通知设置(启用桌面通知、提示音)
- 音频设置(音量滑块、设备选择)
- 其他设置(开机自启动、保存聊天记录)
- 重置按钮(恢复默认设置)
- 使用 Java Preferences API 持久化配置

### 端口释放机制 ✅

**问题背景:**
早期版本客户端关闭后,UDP端口未正确释放,导致每次启动需要使用不同端口。

**解决方案 - 三层保护机制:**

1. **主界面关闭事件处理**
   ```java
   // MainController.java
   stage.setOnCloseRequest(event -> {
       cleanup(); // 立即清理资源
   });
   ```

2. **应用停止钩子**
   ```java
   // SipClientApp.java
   @Override
   public void stop() {
       LoginController.cleanup(); // 确保资源释放
   }
   ```

3. **JVM关闭钩子(最后保险)**
   ```java
   // LoginController.java
   Runtime.getRuntime().addShutdownHook(new Thread(() -> {
       if (globalUserAgent != null) {
           globalUserAgent.shutdown();
       }
   }));
   ```

**关键清理流程:**
```java
// SipUserAgent.shutdown()
public void shutdown() {
    // 1. 先向MSS服务器发送注销(Expires=0)
    if (registered) {
        unregister(Duration.ofSeconds(2));
    }
    
    // 2. 删除ListeningPoint(立即释放UDP端口)
    try {
        sipProvider.removeListeningPoint(listeningPoint);
        sipStack.deleteListeningPoint(listeningPoint);
    } catch (Exception e) {
        log.warning("删除ListeningPoint失败: " + e.getMessage());
    }
    
    // 3. 异步停止SIP栈(避免阻塞)
    new Thread(() -> {
        try {
            sipStack.stop();
        } catch (Exception e) {
            log.warning("停止SIP栈失败: " + e.getMessage());
        }
    }).start();
}
```

**效果验证:**
- ✅ 关闭客户端后,端口5061-5069立即可重用
- ✅ MSS服务器正确显示用户离线
- ✅ 程序关闭不卡顿(200ms内完成)
- ✅ 支持连续快速重启测试

### 测试步骤

**场景 1：GUI 客户端 ↔ 命令行客户端消息测试**

1. 启动 GUI 客户端（用户 101）
   ```powershell
   .\start-gui.ps1
   ```

2. 启动命令行客户端（用户 102）
   ```powershell
   .\start-sip-user102.ps1
   ```

3. 在 GUI 中选择联系人 "102"，输入消息并发送

4. 在 102 终端观察是否收到消息

5. 在 102 终端输入：`msg sip:101@10.29.133.174:5060 你好`

6. GUI 应显示来自 102 的消息

**场景 2：GUI 发起呼叫测试**

1. GUI 中选择联系人 "102"

2. 点击"📞 语音通话"按钮

3. 102 终端应显示来电提示

4. 在 102 终端输入 `Y` 接听

5. GUI 显示通话窗口和计时器

6. 点击挂断按钮结束通话

**场景 3：GUI 接听来电测试**

1. 在 102 终端输入：`call sip:101@10.29.133.174:5060`

2. GUI 弹出来电对话框

3. 点击"✓ 接听"或"✗ 拒接"

### 技术实现

- **框架**: JavaFX 21.0.1
- **布局**: FXML + Controller
- **样式**: 内联 CSS（-fx-* 属性）
- **架构**: MVC 模式
  - **Model**: Contact, Message
  - **View**: FXML 文件
  - **Controller**: LoginController, MainController 等

### 已集成的后端功能

| 功能 | 实现状态 | 调用方法 |
|------|---------|---------|
| SIP 注册 | ✅ | `userAgent.register()` |
| 发送消息 | ✅ | `userAgent.sendMessage()` |
| 接收消息 | ✅ | `MessageHandler.handleIncomingMessage()` |
| 发起呼叫 | ✅ | `userAgent.makeCall()` |
| 接听来电 | ✅ | `userAgent.answerCall()` |
| 拒接来电 | ✅ | `userAgent.rejectCall()` |
| 挂断通话 | ✅ | `userAgent.hangup()` |
| 来电通知 | ✅ | `CallManager.IncomingCallListener` |
| 注销登录 | ✅ | `userAgent.unregister()` + `shutdown()` |
| 端口释放 | ✅ | 三层保护机制(窗口关闭/应用停止/JVM钩子) |

### 待实现功能

- [ ] RTP音频传输(Java Sound API)
- [ ] 静音功能(RTP 控制)
- [ ] 文件传输
- [ ] 群组聊天
- [ ] 视频通话
- [ ] 头像上传/显示
- [ ] 用户状态同步(在线/离线/忙碌)
- [ ] 消息已读回执

---

## 开发指南

### 客户端扩展

**添加新功能示例：**
```java
// 实现音频传输
AudioFormat format = new AudioFormat(8000, 16, 1, true, false);
TargetDataLine microphone = AudioSystem.getTargetDataLine(format);
// 使用 RTPManager 发送音频流
```

### 服务器开发

**待实现：**
- 数据持久化（JPA + MySQL）
- 群聊管理
- 文件存储

---

## 测试指南

### 单元测试
```powershell
# 运行所有测试
mvn clean test

# 运行特定模块测试
mvn -pl sip-client test
mvn -pl admin-server test
```

### 集成测试

详见 `QUICKSTART.md` 中的完整测试场景。

**快速测试：**
1. 启动两个客户端实例（不同端口）
2. 在客户端 A：`msg sip:bob@server 你好`
3. 在客户端 B：观察是否收到消息

---

## 常见问题

### Q: 如何实现客户端 GUI？
A: 推荐使用 JavaFX：
1. 在 `sip-client/pom.xml` 添加 JavaFX 依赖
2. 创建 `src/main/java/com/example/sipclient/ui/gui/` 包
3. 实现 `MainWindow.java`（主窗口）、`ChatPanel.java`（聊天面板）等
4. 参考 JavaFX 官方文档：https://openjfx.io/

### Q: 客户端如何保持长连接？
A: 两种方案：
1. **SIP 协议** - 通过 SIP MESSAGE 接收消息（已实现）
2. **WebSocket** - 连接服务器接收推送（需在服务器添加 WebSocket 支持）

### Q: 如何处理离线消息？
A: 
1. 客户端启动时调用 `GET /api/messages/sessions` 获取未读消息
2. 服务器存储离线消息到数据库
3. 用户上线后推送或拉取离线消息

### Q: 多个客户端如何同步状态？
A: 建议实现：
1. 服务器维护用户在线状态
2. 客户端定期心跳（`PUT /api/auth/status`）
3. 使用 WebSocket 推送状态变化

---

## 开发路线图

**✅ 已完成：**
- SIP 协议实现
- JavaFX 图形界面
- 本地数据存储
- REST API 服务器

**🔄 进行中：**
- RTP 音频传输
- 服务器数据持久化

**📋 计划中：**
- 群聊功能
- 文件传输
- 视频通话

---

## 文档索引

### 核心文档
- **`README.md`** - 完整项目文档（本文件）
- **`QUICKSTART.md`** - 快速启动和测试指南

### 归档文档
- **`docs/archive/TASK-DISTRIBUTION.md`** - 团队任务分配（已归档）
- **`docs/archive/GUI_FEATURES_COMPLETION.md`** - GUI 功能完成报告（已归档）

> 💡 **提示：** 新用户建议先阅读 [QUICKSTART.md](QUICKSTART.md)，快速上手！

---

## 开发规范

**代码风格：**
- 遵循 Google Java Style Guide
- 使用 IDE 自动格式化

**提交规范：**
```
[模块] 简短描述

示例：
[GUI] 添加联系人搜索
[SIP] 修复端口释放问题
[Server] 添加JWT认证
```

---

## 常见问题

**Q: 如何更换 SIP 服务器？**  
A: 修改登录界面的 SIP URI。

**Q: 聊天记录保存在哪里？**  
A: SQLite 数据库文件 `sip_client.db`（项目根目录）。

**Q: 音频通话没有声音？**  
A: 当前只实现了 SIP 信令，RTP 音频传输开发中。

**Q: 如何测试多个客户端？**  
A: 使用不同端口，如 `.\start-sip-user101.ps1` 和 `.\start-sip-user102.ps1`。

---

## 许可证

本项目用于课程学习和技术研究。

## 联系方式

- **项目仓库**: https://github.com/huanxu123/sip
- **问题反馈**: GitHub Issues
- **版本**: 1.0.0-SNAPSHOT
