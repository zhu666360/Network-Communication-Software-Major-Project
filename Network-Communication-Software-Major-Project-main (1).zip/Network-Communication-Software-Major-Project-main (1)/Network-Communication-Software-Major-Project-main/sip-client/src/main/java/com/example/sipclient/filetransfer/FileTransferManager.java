package com.example.sipclient.filetransfer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 文件传输管理器
 * 支持文件分块发送、接收和进度跟踪
 */
public class FileTransferManager {

    private static final Logger log = LoggerFactory.getLogger(FileTransferManager.class);
    private static final int CHUNK_SIZE = 8192; // 8KB 每块
    private static final long MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB 最大文件大小

    // 传输会话：fileId -> FileTransferSession
    private final Map<String, FileTransferSession> transferSessions = new ConcurrentHashMap<>();
    
    // 接收进度监听器
    private FileTransferListener listener;
    
    // 文件接收目录
    private String downloadDir;

    public FileTransferManager(String downloadDir) {
        this.downloadDir = downloadDir;
        // 创建下载目录
        Path dir = Paths.get(downloadDir);
        try {
            Files.createDirectories(dir);
            log.info("文件下载目录: {}", downloadDir);
        } catch (IOException e) {
            log.error("创建下载目录失败: {}", e.getMessage());
        }
    }

    /**
     * 发送文件
     */
    public void sendFile(String targetUri, String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) {
            throw new FileNotFoundException("文件不存在: " + filePath);
        }
        if (!file.isFile()) {
            throw new IOException("不是文件: " + filePath);
        }
        if (file.length() > MAX_FILE_SIZE) {
            throw new IOException("文件过大，超过 100MB 限制");
        }

        String fileId = generateFileId();
        FileTransferSession session = new FileTransferSession(fileId, file, targetUri, true);
        transferSessions.put(fileId, session);

        log.info("开始发送文件: {} (大小: {} 字节)", file.getName(), file.length());
        if (listener != null) {
            listener.onTransferStarted(fileId, file.getName(), file.length());
        }
    }

    /**
     * 接收文件块
     */
    public void receiveFileChunk(String fileId, String fileName, long totalSize, int chunkIndex, byte[] data) {
        FileTransferSession session = transferSessions.get(fileId);
        if (session == null) {
            session = new FileTransferSession(fileId, fileName, totalSize, false);
            transferSessions.put(fileId, session);
            log.info("接收新文件: {} (大小: {} 字节，总块数: {})", 
                fileName, totalSize, (totalSize + CHUNK_SIZE - 1) / CHUNK_SIZE);
            if (listener != null) {
                listener.onTransferStarted(fileId, fileName, totalSize);
            }
        }

        try {
            session.addChunk(chunkIndex, data);
            if (listener != null) {
                listener.onProgress(fileId, session.getReceivedSize());
            }

            // 检查是否传输完成
            if (session.isComplete()) {
                File receivedFile = saveReceivedFile(session);
                transferSessions.remove(fileId);
                log.info("文件接收完成: {}", receivedFile.getAbsolutePath());
                if (listener != null) {
                    listener.onTransferCompleted(fileId, receivedFile.getAbsolutePath());
                }
            }
        } catch (IOException e) {
            log.error("接收文件块失败: {}", e.getMessage());
            transferSessions.remove(fileId);
            if (listener != null) {
                listener.onTransferFailed(fileId, e.getMessage());
            }
        }
    }

    /**
     * 获取下一个文件块
     */
    public byte[] getNextChunk(String fileId) throws IOException {
        FileTransferSession session = transferSessions.get(fileId);
        if (session == null) {
            throw new IOException("传输会话不存在: " + fileId);
        }
        
        return session.getNextChunk(CHUNK_SIZE);
    }

    /**
     * 获取文件块总数
     */
    public int getTotalChunks(String fileId) {
        FileTransferSession session = transferSessions.get(fileId);
        if (session == null) {
            return 0;
        }
        return session.getTotalChunks(CHUNK_SIZE);
    }

    /**
     * 获取当前块索引
     */
    public int getCurrentChunkIndex(String fileId) {
        FileTransferSession session = transferSessions.get(fileId);
        if (session == null) {
            return 0;
        }
        return session.getCurrentChunkIndex();
    }

    /**
     * 保存接收的文件
     */
    private File saveReceivedFile(FileTransferSession session) throws IOException {
        File outputFile = new File(downloadDir, session.getFileName());
        
        // 处理文件名冲突
        int counter = 1;
        while (outputFile.exists()) {
            String name = session.getFileName();
            int lastDot = name.lastIndexOf('.');
            if (lastDot > 0) {
                String baseName = name.substring(0, lastDot);
                String ext = name.substring(lastDot);
                outputFile = new File(downloadDir, baseName + "_" + counter + ext);
            } else {
                outputFile = new File(downloadDir, name + "_" + counter);
            }
            counter++;
        }

        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            byte[] data = session.getAllData();
            fos.write(data);
        }

        return outputFile;
    }

    /**
     * 生成文件传输 ID
     */
    private String generateFileId() {
        return "file_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 10000);
    }

    /**
     * 取消传输
     */
    public void cancelTransfer(String fileId) {
        FileTransferSession session = transferSessions.remove(fileId);
        if (session != null && listener != null) {
            listener.onTransferCancelled(fileId);
        }
        log.info("文件传输已取消: {}", fileId);
    }

    /**
     * 设置监听器
     */
    public void setListener(FileTransferListener listener) {
        this.listener = listener;
    }

    /**
     * 文件传输监听器接口
     */
    public interface FileTransferListener {
        void onTransferStarted(String fileId, String fileName, long totalSize);
        void onProgress(String fileId, long receivedSize);
        void onTransferCompleted(String fileId, String filePath);
        void onTransferFailed(String fileId, String errorMessage);
        void onTransferCancelled(String fileId);
    }

    /**
     * 内部文件传输会话类
     */
    private static class FileTransferSession {
        private final String fileId;
        private final String fileName;
        private final long totalSize;
        private final boolean isSending;
        private final String targetUri;
        
        // 接收模式：块数据映射
        private final Map<Integer, byte[]> chunks = new ConcurrentHashMap<>();
        
        // 发送模式：文件流
        private RandomAccessFile fileStream;
        private int currentChunkIndex = 0;

        // 接收模式：构造函数
        public FileTransferSession(String fileId, String fileName, long totalSize, boolean isSending) {
            this.fileId = fileId;
            this.fileName = fileName;
            this.totalSize = totalSize;
            this.isSending = isSending;
            this.targetUri = null;
        }

        // 发送模式：构造函数
        public FileTransferSession(String fileId, File file, String targetUri, boolean isSending) throws FileNotFoundException {
            this.fileId = fileId;
            this.fileName = file.getName();
            this.totalSize = file.length();
            this.isSending = isSending;
            this.targetUri = targetUri;
            this.fileStream = new RandomAccessFile(file, "r");
        }

        /**
         * 添加接收的块
         */
        public void addChunk(int chunkIndex, byte[] data) {
            chunks.put(chunkIndex, data);
        }

        /**
         * 获取下一个块
         */
        public byte[] getNextChunk(int maxSize) throws IOException {
            if (fileStream == null) {
                return new byte[0];
            }
            
            byte[] buffer = new byte[Math.min(maxSize, (int)(totalSize - fileStream.getFilePointer()))];
            int read = fileStream.read(buffer);
            if (read > 0) {
                currentChunkIndex++;
                if (read < buffer.length) {
                    byte[] trimmed = new byte[read];
                    System.arraycopy(buffer, 0, trimmed, 0, read);
                    return trimmed;
                }
                return buffer;
            }
            return new byte[0];
        }

        /**
         * 获取所有接收的数据
         */
        public byte[] getAllData() throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int totalChunks = getTotalChunks(CHUNK_SIZE);
            
            for (int i = 0; i < totalChunks; i++) {
                byte[] chunk = chunks.get(i);
                if (chunk != null) {
                    baos.write(chunk);
                }
            }
            
            return baos.toByteArray();
        }

        /**
         * 获取已接收的大小
         */
        public long getReceivedSize() {
            return chunks.values().stream().mapToLong(data -> data.length).sum();
        }

        /**
         * 检查传输是否完成
         */
        public boolean isComplete() {
            int totalChunks = getTotalChunks(CHUNK_SIZE);
            return chunks.size() == totalChunks;
        }

        /**
         * 获取总块数
         */
        public int getTotalChunks(int chunkSize) {
            return (int) ((totalSize + chunkSize - 1) / chunkSize);
        }

        /**
         * 获取当前块索引
         */
        public int getCurrentChunkIndex() {
            return currentChunkIndex;
        }

        /**
         * 关闭文件流
         */
        public void close() {
            if (fileStream != null) {
                try {
                    fileStream.close();
                } catch (IOException e) {
                    log.error("关闭文件流失败: {}", e.getMessage());
                }
            }
        }

        public String getFileName() {
            return fileName;
        }

        public String getTargetUri() {
            return targetUri;
        }
    }
}
