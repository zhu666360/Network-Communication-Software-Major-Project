package com.example.sipclient.gui.component;

import com.example.sipclient.gui.model.Message;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * 文件传输消息组件
 */
public class FileMessageBox extends HBox {

    private final Message message;
    private Label fileNameLabel;
    private Label sizeLabel;
    private Label statusLabel;
    private ProgressBar progressBar;
    private Button actionButton;

    public FileMessageBox(Message message, boolean isFromMe) {
        this.message = message;
        setSpacing(10);
        setPadding(new Insets(8, 12, 8, 12));
        setStyle("-fx-background-color: " + (isFromMe ? "#E3F2FD" : "#F5F5F5") + 
                 "; -fx-border-radius: 12; -fx-background-radius: 12;");

        // 文件图标
        Label iconLabel = new Label("📎");
        iconLabel.setStyle("-fx-font-size: 24;");

        // 文件信息
        VBox infoBox = createInfoBox();

        // 操作按钮
        actionButton = new Button();
        updateActionButton();

        getChildren().addAll(iconLabel, infoBox, actionButton);
    }

    private VBox createInfoBox() {
        VBox box = new VBox(5);
        box.setStyle("-fx-padding: 5;");

        // 文件名
        fileNameLabel = new Label(message.getFileName());
        fileNameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 12;");

        // 文件大小
        sizeLabel = new Label(Message.formatFileSize(message.getFileSize()));
        sizeLabel.setStyle("-fx-font-size: 10; -fx-text-fill: #666;");

        // 进度条
        progressBar = new ProgressBar(0);
        progressBar.setPrefWidth(200);
        progressBar.setStyle("-fx-min-height: 6; -fx-padding: 2;");

        // 状态标签
        statusLabel = new Label(message.getFileStatus());
        statusLabel.setStyle("-fx-font-size: 10; -fx-text-fill: #0066CC;");

        box.getChildren().addAll(fileNameLabel, sizeLabel, progressBar, statusLabel);
        return box;
    }

    private void updateActionButton() {
        String status = message.getFileStatus();
        
        if ("COMPLETED".equals(status)) {
            actionButton.setText("📂 打开");
            actionButton.setStyle("-fx-padding: 8 12; -fx-font-size: 11;");
            actionButton.setOnAction(e -> openFile());
        } else if ("FAILED".equals(status)) {
            actionButton.setText("🔄 重试");
            actionButton.setStyle("-fx-padding: 8 12; -fx-font-size: 11;");
            actionButton.setOnAction(e -> retryTransfer());
        } else {
            actionButton.setText("⏹ 取消");
            actionButton.setStyle("-fx-padding: 8 12; -fx-font-size: 11;");
            actionButton.setOnAction(e -> cancelTransfer());
        }
    }

    public void updateProgress(long receivedSize) {
        Platform.runLater(() -> {
            double progress = (double) receivedSize / message.getFileSize();
            progressBar.setProgress(Math.min(progress, 1.0));
            statusLabel.setText(String.format("%.1f%%", progress * 100));
        });
    }

    public void setTransferCompleted(String filePath) {
        Platform.runLater(() -> {
            message.setFilePath(filePath);
            message.setFileStatus("COMPLETED");
            statusLabel.setText("✓ 已完成");
            statusLabel.setStyle("-fx-font-size: 10; -fx-text-fill: #4CAF50;");
            progressBar.setProgress(1.0);
            updateActionButton();
        });
    }

    public void setTransferFailed(String error) {
        Platform.runLater(() -> {
            message.setFileStatus("FAILED");
            statusLabel.setText("✗ 失败: " + error);
            statusLabel.setStyle("-fx-font-size: 10; -fx-text-fill: #F44336;");
            updateActionButton();
        });
    }

    private void openFile() {
        if (message.getFilePath() != null) {
            try {
                String path = message.getFilePath();
                String os = System.getProperty("os.name").toLowerCase();
                
                if (os.contains("win")) {
                    new ProcessBuilder("explorer.exe", "/select,", path).start();
                } else if (os.contains("mac")) {
                    new ProcessBuilder("open", "-R", path).start();
                } else {
                    new ProcessBuilder("xdg-open", path).start();
                }
            } catch (Exception e) {
                System.err.println("打开文件失败: " + e.getMessage());
            }
        }
    }

    private void cancelTransfer() {
        message.setFileStatus("CANCELLED");
        statusLabel.setText("已取消");
        actionButton.setDisable(true);
    }

    private void retryTransfer() {
        message.setFileStatus("RECEIVING");
        progressBar.setProgress(0);
        statusLabel.setText("重新接收中...");
        updateActionButton();
    }

    public Message getMessage() {
        return message;
    }
}
