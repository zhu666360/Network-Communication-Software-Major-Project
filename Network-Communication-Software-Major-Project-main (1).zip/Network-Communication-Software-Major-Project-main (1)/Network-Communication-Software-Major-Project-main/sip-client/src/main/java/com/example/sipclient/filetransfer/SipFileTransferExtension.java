package com.example.sipclient.filetransfer;

import com.example.sipclient.sip.SipUserAgent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * SIP 文件传输扩展
 * 提供在 SIP MESSAGE 上传输文件的能力
 */
public class SipFileTransferExtension {

    private static final Logger log = LoggerFactory.getLogger(SipFileTransferExtension.class);
    
    private final SipUserAgent userAgent;
    private final FileTransferManager fileTransferManager;

    public SipFileTransferExtension(SipUserAgent userAgent, FileTransferManager fileTransferManager) {
        this.userAgent = userAgent;
        this.fileTransferManager = fileTransferManager;
    }

    /**
     * 发送文件
     * 1. 向接收方发送 FILE_REQUEST 消息
     * 2. 逐块发送文件内容
     * 3. 接收确认并继续
     */
    public void sendFile(String targetUri, String filePath) throws Exception {
        log.info("开始发送文件到 {}: {}", targetUri, filePath);
        
        // 启动文件传输
        fileTransferManager.sendFile(targetUri, filePath);
        
        // 获取传输会话信息以及目标 URI
        // 这里需要从 FileTransferManager 中获取刚创建的会话
        // 实际实现中应该修改 FileTransferManager 返回会话信息
        
        // 发送文件请求消息
        sendFileRequest(targetUri, filePath);
    }

    /**
     * 发送文件请求消息
     */
    private void sendFileRequest(String targetUri, String filePath) {
        try {
            java.io.File file = new java.io.File(filePath);
            String fileId = generateFileId();
            int totalChunks = (int) ((file.length() + 8191) / 8192);
            
            FileMessage fileMsg = FileMessage.createFileRequest(
                fileId, 
                file.getName(), 
                file.length(), 
                totalChunks
            );
            
            String messageBody = fileMsg.toMessageBody();
            userAgent.sendMessage(targetUri, messageBody);
            
            log.info("文件请求已发送: fileId={}, 总块数={}", fileId, totalChunks);
        } catch (Exception e) {
            log.error("发送文件请求失败: {}", e.getMessage());
        }
    }

    /**
     * 处理传入的文件消息
     */
    public void handleIncomingFileMessage(String fromUri, String messageBody) {
        try {
            String json = FileMessage.extractJson(messageBody);
            FileMessage fileMsg = FileMessage.fromJson(json);
            
            switch (fileMsg.getType()) {
                case FileMessage.TYPE_FILE_REQUEST:
                    handleFileRequest(fromUri, fileMsg);
                    break;
                case FileMessage.TYPE_FILE_CHUNK:
                    handleFileChunk(fromUri, fileMsg);
                    break;
                case FileMessage.TYPE_FILE_COMPLETE:
                    handleFileComplete(fromUri, fileMsg);
                    break;
                case FileMessage.TYPE_FILE_CANCEL:
                    handleFileCancel(fromUri, fileMsg);
                    break;
                default:
                    log.warn("未知的文件消息类型: {}", fileMsg.getType());
            }
        } catch (Exception e) {
            log.error("处理文件消息失败: {}", e.getMessage());
        }
    }

    /**
     * 处理文件请求
     */
    private void handleFileRequest(String fromUri, FileMessage fileMsg) {
        log.info("收到文件传输请求: {} (大小: {} 字节)", fileMsg.getFileName(), fileMsg.getTotalSize());
        fileTransferManager.receiveFileChunk(
            fileMsg.getFileId(),
            fileMsg.getFileName(),
            fileMsg.getTotalSize(),
            -1,  // 标记为文件开始
            new byte[0]
        );
        
        try {
            // 发送确认
            FileMessage ackMsg = FileMessage.createFileAck(fileMsg.getFileId(), -1);
            String ackBody = ackMsg.toMessageBody();
            userAgent.sendMessage(fromUri, ackBody);
        } catch (Exception e) {
            log.error("发送文件确认失败: {}", e.getMessage());
        }
    }

    /**
     * 处理文件块
     */
    private void handleFileChunk(String fromUri, FileMessage fileMsg) {
        byte[] data = fileMsg.decodeChunkData();
        fileTransferManager.receiveFileChunk(
            fileMsg.getFileId(),
            "",  // 文件名已在 REQUEST 中发送
            0,   // 总大小已在 REQUEST 中发送
            fileMsg.getChunkIndex(),
            data
        );
        
        try {
            // 发送块确认
            FileMessage ackMsg = FileMessage.createFileAck(fileMsg.getFileId(), fileMsg.getChunkIndex());
            String ackBody = ackMsg.toMessageBody();
            userAgent.sendMessage(fromUri, ackBody);
        } catch (Exception e) {
            log.error("发送块确认失败: {}", e.getMessage());
        }
    }

    /**
     * 处理文件完成
     */
    private void handleFileComplete(String fromUri, FileMessage fileMsg) {
        log.info("文件传输完成: {}", fileMsg.getFileId());
        // 文件已在 receiveFileChunk 中保存
    }

    /**
     * 处理文件取消
     */
    private void handleFileCancel(String fromUri, FileMessage fileMsg) {
        log.info("文件传输已取消 ({}): {}", fileMsg.getFileId(), fileMsg.getStatus());
        fileTransferManager.cancelTransfer(fileMsg.getFileId());
    }

    /**
     * 生成文件传输 ID
     */
    private String generateFileId() {
        return "file_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 10000);
    }

    /**
     * 设置文件传输监听器
     */
    public void setFileTransferListener(FileTransferManager.FileTransferListener listener) {
        fileTransferManager.setListener(listener);
    }
}
