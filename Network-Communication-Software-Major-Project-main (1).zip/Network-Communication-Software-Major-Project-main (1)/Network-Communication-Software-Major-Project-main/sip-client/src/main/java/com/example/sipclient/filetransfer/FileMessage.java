package com.example.sipclient.filetransfer;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Base64;

/**
 * 文件传输消息协议
 * 用于编码/解码在 SIP MESSAGE 中传输的文件数据
 */
public class FileMessage {

    private static final Logger log = LoggerFactory.getLogger(FileMessage.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();
    
    // 消息类型
    public static final String TYPE_FILE_REQUEST = "FILE_REQUEST";      // 文件传输开始请求
    public static final String TYPE_FILE_CHUNK = "FILE_CHUNK";          // 文件块数据
    public static final String TYPE_FILE_ACK = "FILE_ACK";              // 文件块确认
    public static final String TYPE_FILE_CANCEL = "FILE_CANCEL";        // 取消传输
    public static final String TYPE_FILE_COMPLETE = "FILE_COMPLETE";    // 传输完成

    private String type;           // 消息类型
    private String fileId;         // 文件传输 ID
    private String fileName;       // 文件名
    private long totalSize;        // 文件总大小
    private int totalChunks;       // 总块数
    private int chunkIndex;        // 当前块索引
    private String chunkData;      // Base64 编码的块数据
    private String status;         // 状态信息

    // 构造函数
    public FileMessage() {}

    public FileMessage(String type, String fileId) {
        this.type = type;
        this.fileId = fileId;
    }

    /**
     * 创建文件传输开始请求
     */
    public static FileMessage createFileRequest(String fileId, String fileName, long totalSize, int totalChunks) {
        FileMessage msg = new FileMessage(TYPE_FILE_REQUEST, fileId);
        msg.fileName = fileName;
        msg.totalSize = totalSize;
        msg.totalChunks = totalChunks;
        return msg;
    }

    /**
     * 创建文件块消息
     */
    public static FileMessage createFileChunk(String fileId, int chunkIndex, byte[] data) {
        FileMessage msg = new FileMessage(TYPE_FILE_CHUNK, fileId);
        msg.chunkIndex = chunkIndex;
        msg.chunkData = Base64.getEncoder().encodeToString(data);
        return msg;
    }

    /**
     * 创建文件块确认
     */
    public static FileMessage createFileAck(String fileId, int chunkIndex) {
        FileMessage msg = new FileMessage(TYPE_FILE_ACK, fileId);
        msg.chunkIndex = chunkIndex;
        return msg;
    }

    /**
     * 创建传输完成消息
     */
    public static FileMessage createFileComplete(String fileId) {
        FileMessage msg = new FileMessage(TYPE_FILE_COMPLETE, fileId);
        msg.status = "SUCCESS";
        return msg;
    }

    /**
     * 创建传输取消消息
     */
    public static FileMessage createFileCancel(String fileId, String reason) {
        FileMessage msg = new FileMessage(TYPE_FILE_CANCEL, fileId);
        msg.status = reason;
        return msg;
    }

    /**
     * 转换为 JSON 字符串
     */
    public String toJson() throws IOException {
        return objectMapper.writeValueAsString(this);
    }

    /**
     * 从 JSON 字符串解析
     */
    public static FileMessage fromJson(String json) throws IOException {
        return objectMapper.readValue(json, FileMessage.class);
    }

    /**
     * 从消息体解析（消息体以 "[FILE]" 开头）
     */
    public static boolean isFileMessage(String body) {
        return body != null && body.startsWith("[FILE]");
    }

    /**
     * 提取 JSON 内容
     */
    public static String extractJson(String body) {
        if (body.startsWith("[FILE]")) {
            return body.substring(6);
        }
        return body;
    }

    /**
     * 包装为消息体
     */
    public String toMessageBody() throws IOException {
        return "[FILE]" + toJson();
    }

    /**
     * 解码块数据
     */
    public byte[] decodeChunkData() {
        if (chunkData == null) {
            return new byte[0];
        }
        return Base64.getDecoder().decode(chunkData);
    }

    // Getters and Setters
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public long getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(long totalSize) {
        this.totalSize = totalSize;
    }

    public int getTotalChunks() {
        return totalChunks;
    }

    public void setTotalChunks(int totalChunks) {
        this.totalChunks = totalChunks;
    }

    public int getChunkIndex() {
        return chunkIndex;
    }

    public void setChunkIndex(int chunkIndex) {
        this.chunkIndex = chunkIndex;
    }

    public String getChunkData() {
        return chunkData;
    }

    public void setChunkData(String chunkData) {
        this.chunkData = chunkData;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
