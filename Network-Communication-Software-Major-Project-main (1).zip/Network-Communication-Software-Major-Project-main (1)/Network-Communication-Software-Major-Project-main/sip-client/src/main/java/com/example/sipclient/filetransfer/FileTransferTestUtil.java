package com.example.sipclient.filetransfer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;

/**
 * 文件传输测试工具类
 * 用于测试和验证文件传输功能
 */
public class FileTransferTestUtil {

    private static final Logger log = LoggerFactory.getLogger(FileTransferTestUtil.class);

    /**
     * 创建测试 Word 文件
     */
    public static File createTestWordFile(String fileName, long sizeInMB) throws IOException {
        File file = new File(fileName);
        
        // 创建一个简单的 DOCX 文件（实际上是 ZIP 格式）
        byte[] content = generateTestContent(sizeInMB);
        
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(content);
        }
        
        log.info("创建测试文件: {} (大小: {}MB)", fileName, sizeInMB);
        return file;
    }

    /**
     * 生成测试内容
     */
    private static byte[] generateTestContent(long sizeInMB) {
        long totalSize = sizeInMB * 1024 * 1024;
        byte[] content = new byte[(int) Math.min(totalSize, Integer.MAX_VALUE)];
        
        // 填充测试数据
        for (int i = 0; i < content.length; i++) {
            content[i] = (byte) (i % 256);
        }
        
        return content;
    }

    /**
     * 计算文件哈希值（用于完整性验证）
     */
    public static String calculateFileMD5(String filePath) throws Exception {
        byte[] content = Files.readAllBytes(Paths.get(filePath));
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] hashBytes = md.digest(content);
        
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        
        return hexString.toString();
    }

    /**
     * 验证接收的文件
     */
    public static boolean verifyFile(String originalPath, String receivedPath) throws Exception {
        String originalMD5 = calculateFileMD5(originalPath);
        String receivedMD5 = calculateFileMD5(receivedPath);
        
        boolean match = originalMD5.equals(receivedMD5);
        log.info("文件验证: {} (原始: {}, 接收: {})", 
            match ? "成功" : "失败", 
            originalMD5, 
            receivedMD5);
        
        return match;
    }

    /**
     * 格式化文件大小
     */
    public static String formatFileSize(long bytes) {
        if (bytes <= 0) return "0 B";
        final String[] units = {"B", "KB", "MB", "GB"};
        int digitGroups = (int) (Math.log10(bytes) / Math.log10(1024));
        return String.format("%.2f %s", 
            bytes / Math.pow(1024, digitGroups), 
            units[digitGroups]);
    }

    /**
     * 模拟文件传输性能测试
     */
    public static void performanceTest(int chunkCount, int chunkSize) {
        log.info("开始性能测试: 块数={}, 块大小={}", chunkCount, chunkSize);
        
        long totalSize = (long) chunkCount * chunkSize;
        long startTime = System.currentTimeMillis();
        
        // 模拟传输
        for (int i = 0; i < chunkCount; i++) {
            // 模拟网络延迟 (5ms)
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;
        double speed = totalSize * 1000.0 / (duration * 1024 * 1024); // MB/s
        
        log.info("性能测试完成:");
        log.info("  总大小: {} MB", totalSize / (1024 * 1024));
        log.info("  总耗时: {} ms", duration);
        log.info("  平均速度: {:.2f} MB/s", speed);
    }

    /**
     * 测试场景: 小文件传输
     */
    public static class SmallFileTransferTest {
        public static void run() throws Exception {
            log.info("=== 小文件传输测试 ===");
            
            File testFile = createTestWordFile("/tmp/test_small.docx", 1);
            log.info("创建测试文件: {} 字节", testFile.length());
            
            // 验证文件
            String md5 = calculateFileMD5(testFile.getAbsolutePath());
            log.info("文件 MD5: {}", md5);
            
            // 清理
            Files.delete(testFile.toPath());
            log.info("测试完成\n");
        }
    }

    /**
     * 测试场景: 大文件传输
     */
    public static class LargeFileTransferTest {
        public static void run() throws Exception {
            log.info("=== 大文件传输测试 ===");
            
            File testFile = createTestWordFile("/tmp/test_large.docx", 50);
            log.info("创建测试文件: {} MB", testFile.length() / (1024 * 1024));
            
            // 计算块数
            int chunkSize = 8192;
            int totalChunks = (int) ((testFile.length() + chunkSize - 1) / chunkSize);
            log.info("总块数: {}", totalChunks);
            
            // 性能测试
            performanceTest(totalChunks, chunkSize);
            
            // 清理
            Files.delete(testFile.toPath());
            log.info("测试完成\n");
        }
    }

    /**
     * 测试场景: 多文件并发传输
     */
    public static class ConcurrentFileTransferTest {
        public static void run() throws Exception {
            log.info("=== 多文件并发传输测试 ===");
            
            // 创建多个测试文件
            File[] files = new File[3];
            for (int i = 0; i < 3; i++) {
                files[i] = createTestWordFile("/tmp/test_concurrent_" + i + ".docx", 10);
            }
            
            log.info("创建了 {} 个测试文件", files.length);
            
            // 模拟并发传输
            long startTime = System.currentTimeMillis();
            
            Thread[] threads = new Thread[files.length];
            for (int i = 0; i < files.length; i++) {
                final File file = files[i];
                threads[i] = new Thread(() -> {
                    try {
                        String md5 = calculateFileMD5(file.getAbsolutePath());
                        log.info("文件 {} 传输完成: {}", file.getName(), md5);
                    } catch (Exception e) {
                        log.error("文件传输失败", e);
                    }
                });
                threads[i].start();
            }
            
            // 等待所有线程完成
            for (Thread thread : threads) {
                thread.join();
            }
            
            long duration = System.currentTimeMillis() - startTime;
            log.info("并发传输完成, 耗时: {} ms\n", duration);
            
            // 清理
            for (File file : files) {
                Files.delete(file.toPath());
            }
        }
    }

    /**
     * 测试场景: 文件分块验证
     */
    public static class FileChunkVerificationTest {
        public static void run() throws Exception {
            log.info("=== 文件分块验证测试 ===");
            
            File testFile = createTestWordFile("/tmp/test_chunk.docx", 10);
            
            // 读取文件并分块
            byte[] fileContent = Files.readAllBytes(testFile.toPath());
            int chunkSize = 8192;
            int chunkCount = (fileContent.length + chunkSize - 1) / chunkSize;
            
            log.info("文件大小: {} 字节", fileContent.length);
            log.info("块大小: {} 字节", chunkSize);
            log.info("总块数: {}", chunkCount);
            
            // 模拟分块和重组
            byte[][] chunks = new byte[chunkCount][];
            int offset = 0;
            
            for (int i = 0; i < chunkCount; i++) {
                int size = Math.min(chunkSize, fileContent.length - offset);
                chunks[i] = new byte[size];
                System.arraycopy(fileContent, offset, chunks[i], 0, size);
                offset += size;
                log.info("块 {}: {} 字节", i, size);
            }
            
            // 重组文件
            java.io.ByteArrayOutputStream reconstructed = new java.io.ByteArrayOutputStream();
            for (byte[] chunk : chunks) {
                reconstructed.write(chunk);
            }
            
            byte[] reconstructedContent = reconstructed.toByteArray();
            
            // 验证
            boolean match = java.util.Arrays.equals(fileContent, reconstructedContent);
            log.info("分块重组验证: {}", match ? "成功" : "失败");
            
            // 清理
            Files.delete(testFile.toPath());
            log.info("测试完成\n");
        }
    }

    /**
     * 运行所有测试
     */
    public static void runAllTests() throws Exception {
        log.info("开始执行所有测试\n");
        
        SmallFileTransferTest.run();
        LargeFileTransferTest.run();
        ConcurrentFileTransferTest.run();
        FileChunkVerificationTest.run();
        
        log.info("所有测试完成！");
    }

    public static void main(String[] args) throws Exception {
        // 运行测试
        if (args.length > 0) {
            switch (args[0]) {
                case "small":
                    SmallFileTransferTest.run();
                    break;
                case "large":
                    LargeFileTransferTest.run();
                    break;
                case "concurrent":
                    ConcurrentFileTransferTest.run();
                    break;
                case "chunk":
                    FileChunkVerificationTest.run();
                    break;
                case "all":
                default:
                    runAllTests();
            }
        } else {
            runAllTests();
        }
    }
}
