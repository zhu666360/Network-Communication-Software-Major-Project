package com.example.sipclient.gui.model;

import java.time.LocalDateTime;

/**
 * 消息模型
 * 支持文本消息和文件消息
 */
public class Message {
    
    // 消息类型
    public enum MessageType {
        TEXT,      // 文本消息
        FILE       // 文件消息
    }

    private String content;
    private boolean fromMe;
    private LocalDateTime timestamp;
    private MessageType type;
    
    // 文件相关字段（当 type = FILE 时有效）
    private String fileId;         // 文件传输 ID
    private String fileName;       // 文件名
    private long fileSize;         // 文件大小（字节）
    private String filePath;       // 本地文件路径
    private String fileStatus;     // 文件状态：SENDING, RECEIVING, COMPLETED, FAILED

    // 文本消息构造函数
    public Message(String content, boolean fromMe, LocalDateTime timestamp) {
        this.content = content;
        this.fromMe = fromMe;
        this.timestamp = timestamp;
        this.type = MessageType.TEXT;
    }

    // 文件消息构造函数
    public Message(String fileId, String fileName, long fileSize, boolean fromMe, LocalDateTime timestamp) {
        this.fileId = fileId;
        this.fileName = fileName;
        this.fileSize = fileSize;
        this.fromMe = fromMe;
        this.timestamp = timestamp;
        this.type = MessageType.FILE;
        this.fileStatus = "RECEIVING";
        this.content = "📎 " + fileName + " (" + formatFileSize(fileSize) + ")";
    }

    /**
     * 格式化文件大小
     */
    public static String formatFileSize(long size) {
        if (size <= 0) return "0 B";
        final String[] units = new String[]{"B", "KB", "MB", "GB"};
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        return String.format("%.2f %s", size / Math.pow(1024, digitGroups), units[digitGroups]);
    }

    public String getContent() {
        return content;
    }

    public boolean isFromMe() {
        return fromMe;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public MessageType getType() {
        return type;
    }

    public String getFileId() {
        return fileId;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getFileStatus() {
        return fileStatus;
    }

    public void setFileStatus(String fileStatus) {
        this.fileStatus = fileStatus;
    }

    /**
     * 检查是否是文件消息
     */
    public boolean isFileMessage() {
        return type == MessageType.FILE;
    }

    /**
     * 检查文件是否已完成接收
     */
    public boolean isFileCompleted() {
        return "COMPLETED".equals(fileStatus);
    }
}
