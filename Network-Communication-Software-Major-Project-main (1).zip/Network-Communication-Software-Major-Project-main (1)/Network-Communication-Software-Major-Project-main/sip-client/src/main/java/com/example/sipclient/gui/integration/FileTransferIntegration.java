package com.example.sipclient.gui.integration;

import com.example.sipclient.filetransfer.FileMessage;
import com.example.sipclient.filetransfer.FileTransferManager;
import com.example.sipclient.filetransfer.SipFileTransferExtension;
import com.example.sipclient.gui.model.Message;
import com.example.sipclient.sip.SipUserAgent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.function.Consumer;

/**
 * GUI 与文件传输的集成类
 * 负责在主应用中正确集成文件传输功能
 */
public class FileTransferIntegration {

    private static final Logger log = LoggerFactory.getLogger(FileTransferIntegration.class);

    private final SipUserAgent userAgent;
    private final FileTransferManager fileTransferManager;
    private final SipFileTransferExtension fileTransferExtension;
    
    // 消息回调
    private Consumer<Message> onMessageReceived;
    private Consumer<String> onStatusUpdate;

    public FileTransferIntegration(SipUserAgent userAgent) throws Exception {
        this.userAgent = userAgent;
        
        // 初始化文件传输管理器
        String downloadDir = System.getProperty("user.home") + "/SipClientFiles";
        this.fileTransferManager = new FileTransferManager(downloadDir);
        
        // 初始化 SIP 文件传输扩展
        this.fileTransferExtension = new SipFileTransferExtension(userAgent, fileTransferManager);
        
        // 设置文件传输监听器
        setupFileTransferListener();
        
        log.info("文件传输模块已初始化");
    }

    /**
     * 设置文件传输监听器
     */
    private void setupFileTransferListener() {
        fileTransferManager.setListener(new FileTransferManager.FileTransferListener() {
            @Override
            public void onTransferStarted(String fileId, String fileName, long totalSize) {
                log.info("文件传输开始: {} ({}字节)", fileName, totalSize);
                if (onStatusUpdate != null) {
                    onStatusUpdate.accept("开始传输文件: " + fileName);
                }
            }

            @Override
            public void onProgress(String fileId, long receivedSize) {
                if (onStatusUpdate != null) {
                    int percentage = (int) (receivedSize * 100 / fileTransferManager.getTotalChunks(fileId) / 8192);
                    onStatusUpdate.accept("传输进度: " + percentage + "%");
                }
            }

            @Override
            public void onTransferCompleted(String fileId, String filePath) {
                log.info("文件传输完成: {}", filePath);
                if (onStatusUpdate != null) {
                    onStatusUpdate.accept("✓ 文件接收完成: " + filePath);
                }
            }

            @Override
            public void onTransferFailed(String fileId, String errorMessage) {
                log.error("文件传输失败: {}", errorMessage);
                if (onStatusUpdate != null) {
                    onStatusUpdate.accept("✗ 传输失败: " + errorMessage);
                }
            }

            @Override
            public void onTransferCancelled(String fileId) {
                log.info("文件传输已取消: {}", fileId);
                if (onStatusUpdate != null) {
                    onStatusUpdate.accept("传输已取消");
                }
            }
        });
    }

    /**
     * 处理传入的消息（包括文本和文件）
     */
    public void handleIncomingMessage(String fromUri, String messageBody) {
        try {
            // 检查是否是文件消息
            if (FileMessage.isFileMessage(messageBody)) {
                // 处理文件消息
                String json = FileMessage.extractJson(messageBody);
                FileMessage fileMsg = FileMessage.fromJson(json);
                
                handleIncomingFileMessage(fromUri, fileMsg);
            } else {
                // 处理文本消息
                Message msg = new Message(messageBody, false, LocalDateTime.now());
                if (onMessageReceived != null) {
                    onMessageReceived.accept(msg);
                }
            }
        } catch (Exception e) {
            log.error("处理消息失败: {}", e.getMessage());
        }
    }

    /**
     * 处理传入的文件消息
     */
    private void handleIncomingFileMessage(String fromUri, FileMessage fileMsg) {
        try {
            switch (fileMsg.getType()) {
                case FileMessage.TYPE_FILE_REQUEST:
                    handleFileRequest(fromUri, fileMsg);
                    break;
                case FileMessage.TYPE_FILE_CHUNK:
                    handleFileChunk(fromUri, fileMsg);
                    break;
                case FileMessage.TYPE_FILE_COMPLETE:
                    handleFileComplete(fromUri, fileMsg);
                    break;
                case FileMessage.TYPE_FILE_CANCEL:
                    handleFileCancel(fromUri, fileMsg);
                    break;
                default:
                    log.warn("未知的文件消息类型: {}", fileMsg.getType());
            }
        } catch (Exception e) {
            log.error("处理文件消息失败: {}", e.getMessage());
        }
    }

    /**
     * 处理文件传输请求
     */
    private void handleFileRequest(String fromUri, FileMessage fileMsg) throws Exception {
        log.info("收到文件传输请求: {} (大小: {} 字节)", 
            fileMsg.getFileName(), fileMsg.getTotalSize());

        // 创建文件消息并通知 UI
        Message fileMessage = new Message(
            fileMsg.getFileId(),
            fileMsg.getFileName(),
            fileMsg.getTotalSize(),
            false,
            LocalDateTime.now()
        );

        if (onMessageReceived != null) {
            onMessageReceived.accept(fileMessage);
        }

        // 初始化接收（标记为-1表示开始）
        fileTransferManager.receiveFileChunk(
            fileMsg.getFileId(),
            fileMsg.getFileName(),
            fileMsg.getTotalSize(),
            -1,
            new byte[0]
        );

        // 发送确认
        FileMessage ackMsg = FileMessage.createFileAck(fileMsg.getFileId(), -1);
        userAgent.sendMessage(fromUri, ackMsg.toMessageBody());
        
        if (onStatusUpdate != null) {
            onStatusUpdate.accept("准备接收文件: " + fileMsg.getFileName());
        }
    }

    /**
     * 处理文件块
     */
    private void handleFileChunk(String fromUri, FileMessage fileMsg) throws Exception {
        byte[] data = fileMsg.decodeChunkData();
        
        fileTransferManager.receiveFileChunk(
            fileMsg.getFileId(),
            "",
            0,
            fileMsg.getChunkIndex(),
            data
        );

        // 发送块确认
        FileMessage ackMsg = FileMessage.createFileAck(fileMsg.getFileId(), fileMsg.getChunkIndex());
        userAgent.sendMessage(fromUri, ackMsg.toMessageBody());
    }

    /**
     * 处理文件完成
     */
    private void handleFileComplete(String fromUri, FileMessage fileMsg) {
        log.info("文件传输完成: {}", fileMsg.getFileId());
    }

    /**
     * 处理文件取消
     */
    private void handleFileCancel(String fromUri, FileMessage fileMsg) {
        log.info("文件传输已取消: {}", fileMsg.getFileId());
        fileTransferManager.cancelTransfer(fileMsg.getFileId());
    }

    /**
     * 发送文件
     */
    public void sendFile(String targetUri, String filePath) throws Exception {
        log.info("发送文件到 {}: {}", targetUri, filePath);
        fileTransferExtension.sendFile(targetUri, filePath);
    }

    /**
     * 设置消息接收回调
     */
    public void setOnMessageReceived(Consumer<Message> callback) {
        this.onMessageReceived = callback;
    }

    /**
     * 设置状态更新回调
     */
    public void setOnStatusUpdate(Consumer<String> callback) {
        this.onStatusUpdate = callback;
    }

    /**
     * 获取文件传输管理器
     */
    public FileTransferManager getFileTransferManager() {
        return fileTransferManager;
    }

    /**
     * 关闭文件传输模块
     */
    public void shutdown() {
        log.info("关闭文件传输模块");
        // 清理资源
    }
}
